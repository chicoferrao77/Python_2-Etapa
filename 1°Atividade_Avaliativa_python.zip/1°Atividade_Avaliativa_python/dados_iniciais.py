from models import db
from models.filme import Filme 
from models.sala import Sala



def popular_dados():
    if Filme.query.count() > 0:
        return
    
    filmes = [
        Filme(titulo="Croods", duracao=98, classificacao="L"),
        Filme(titulo="Era do Gelo", duracao=81, classificacao="L"),
    ]

    salas = [
        Sala(numero=1, capacidade=90),
        Sala(numero=2, capacidade=90),
    ]

    db.session.add_all(filmes + salas)
    db.session.commit()
